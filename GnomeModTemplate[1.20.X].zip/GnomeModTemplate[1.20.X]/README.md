# Gnome's minecraft mod template with Fabric API.
## Version: 1.20.X, X>=4
